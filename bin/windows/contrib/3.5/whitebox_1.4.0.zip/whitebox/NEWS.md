# whitebox 0.3.0

* update to [WhiteboxTools v0.15.0](https://github.com/jblindsay/whitebox-tools/releases)

# whitebox 0.2.0

* Change the way to download WBT binaries

# whitebox 0.1.1

* Update to use secure download mechanisms (https)

# whitebox 0.1

* Initial release
These example and test data are a derivative of the

* _[Geoland.at](https://www.data.gv.at/katalog/dataset/d88a1246-9684-480b-a480-ff63286b35b7)_ (digital elevation model),
* _[AMA](https://www.data.gv.at/katalog/dataset/35e36014-ec69-439b-8629-389f52ffaa92)_ (field data),
* _[BMLRT](https://www.data.gv.at/katalog/dataset/c2287ccb-f44c-48cd-bf7c-ac107b771246)_ (channel data) and
* _[GIP.at](https://www.data.gv.at/katalog/dataset/3fefc838-791d-4dde-975b-a4131a54e7c5)_ (road data)

data sets, used and licensed under _[(CC BY 4.0)](https://creativecommons.org/licenses/by/4.0)_ by Gerold Hepp.
